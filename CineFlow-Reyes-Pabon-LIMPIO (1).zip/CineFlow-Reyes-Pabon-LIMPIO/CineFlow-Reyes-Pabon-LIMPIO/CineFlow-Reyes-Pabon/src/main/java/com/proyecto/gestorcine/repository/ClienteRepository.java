package com.proyecto.gestorcine.repository;

import com.proyecto.gestorcine.entity.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepository extends JpaRepository<Cliente, String> {
}
