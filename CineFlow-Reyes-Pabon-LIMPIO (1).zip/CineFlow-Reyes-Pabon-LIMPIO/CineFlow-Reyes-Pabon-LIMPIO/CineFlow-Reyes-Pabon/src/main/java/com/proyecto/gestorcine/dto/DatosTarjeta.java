package com.proyecto.gestorcine.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor


public class DatosTarjeta {

    private String numero;
    private String titular;
    private String vencimiento;
    private String cvv;
    private int fondos;
}
