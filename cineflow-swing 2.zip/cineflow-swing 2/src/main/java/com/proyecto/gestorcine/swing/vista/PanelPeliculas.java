package com.proyecto.gestorcine.swing.vista;

import com.fasterxml.jackson.core.type.TypeReference;
import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.Pelicula;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelPeliculas extends JPanel {

    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new String[]{"Codigo", "Nombre", "Genero", "Duracion", "Director"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable tabla = new JTable(modeloTabla);

    private final JTextField campoNombre = new JTextField(14);
    private final JComboBox<String> comboGenero = new JComboBox<>(Pelicula.GENEROS);
    private final JTextField campoDuracion = new JTextField(4);
    private final JTextField campoDirector = new JTextField(12);
    private final JTextField campoActores = new JTextField(14);
    private final JTextField campoSinopsis = new JTextField(16);

    public PanelPeliculas() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(construirFormulario(), BorderLayout.SOUTH);

        cargarPeliculas();
    }

    private JPanel construirFormulario() {
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);

        String[] etiquetas = {"Nombre", "Genero", "Duracion", "Director", "Actores", "Sinopsis"};
        JComponent[] campos = {campoNombre, comboGenero, campoDuracion, campoDirector, campoActores, campoSinopsis};

        gbc.gridy = 0;
        for (int i = 0; i < etiquetas.length; i++) {
            gbc.gridx = i;
            panelFormulario.add(new JLabel(etiquetas[i]), gbc);
        }
        gbc.gridy = 1;
        for (int i = 0; i < campos.length; i++) {
            gbc.gridx = i;
            panelFormulario.add(campos[i], gbc);
        }

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton botonAgregar = new JButton("Agregar pelicula");
        JButton botonEliminar = new JButton("Eliminar seleccionada");
        JButton botonRefrescar = new JButton("Refrescar");
        panelBotones.add(botonAgregar);
        panelBotones.add(botonEliminar);
        panelBotones.add(botonRefrescar);

        botonAgregar.addActionListener(e -> agregarPelicula());
        botonEliminar.addActionListener(e -> eliminarSeleccionada());
        botonRefrescar.addActionListener(e -> cargarPeliculas());

        JPanel contenedor = new JPanel(new BorderLayout());
        contenedor.add(panelFormulario, BorderLayout.NORTH);
        contenedor.add(panelBotones, BorderLayout.SOUTH);
        return contenedor;
    }

    private void cargarPeliculas() {
        try {
            List<Pelicula> peliculas = ApiClient.get("/api/peliculas", new TypeReference<List<Pelicula>>() {});
            modeloTabla.setRowCount(0);
            for (Pelicula p : peliculas) {
                modeloTabla.addRow(new Object[]{
                        p.getCodigoPelicula(), p.getNombre(), p.getGenero(), p.getDuracion(), p.getDirector()
                });
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar peliculas", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarPelicula() {
        try {
            int duracion = Integer.parseInt(campoDuracion.getText().trim());
            String nombre = campoNombre.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede estar vacio.", "Dato faltante", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Pelicula nueva = new Pelicula(null, nombre, (String) comboGenero.getSelectedItem(), duracion,
                    campoDirector.getText().trim(), campoActores.getText().trim(), campoSinopsis.getText().trim());

            ApiClient.post("/api/peliculas", nueva, Pelicula.class);
            campoNombre.setText(""); campoDuracion.setText(""); campoDirector.setText("");
            campoActores.setText(""); campoSinopsis.setText("");
            cargarPeliculas();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La duracion debe ser un numero.", "Datos invalidos", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo agregar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarSeleccionada() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una pelicula de la tabla primero.", "Nada seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        int confirmacion = JOptionPane.showConfirmDialog(this,
                "¿Eliminar la pelicula con codigo " + codigo + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirmacion != JOptionPane.YES_OPTION) return;
        try {
            ApiClient.delete("/api/peliculas/" + codigo);
            cargarPeliculas();
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }
}
