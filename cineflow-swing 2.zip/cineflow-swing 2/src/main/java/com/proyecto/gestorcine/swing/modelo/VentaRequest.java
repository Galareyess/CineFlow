package com.proyecto.gestorcine.swing.modelo;

public class VentaRequest {
    private Reserva reserva;
    private DatosTarjeta tarjeta;

    public VentaRequest() {}
    public VentaRequest(Reserva reserva, DatosTarjeta tarjeta) {
        this.reserva = reserva; this.tarjeta = tarjeta;
    }

    public Reserva getReserva() { return reserva; }
    public void setReserva(Reserva reserva) { this.reserva = reserva; }
    public DatosTarjeta getTarjeta() { return tarjeta; }
    public void setTarjeta(DatosTarjeta tarjeta) { this.tarjeta = tarjeta; }
}
