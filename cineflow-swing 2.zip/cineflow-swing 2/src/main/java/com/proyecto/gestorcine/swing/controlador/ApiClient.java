package com.proyecto.gestorcine.swing.controlador;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Map;

public class ApiClient {

    private static final String BASE_URL = "http://localhost:8080";
    private static final HttpClient CLIENT = HttpClient.newHttpClient();
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);


    private ApiClient() {}

    public static class ApiException extends RuntimeException {
        public ApiException(String mensaje) { super(mensaje); }
    }

    public static <T> T get(String path, Class<T> tipo) {
        return enviarYParsear(HttpRequest.newBuilder(URI.create(BASE_URL + path)).GET().build(), tipo);
    }

    /**
     * Para endpoints que devuelven un String "pelado": algunas versiones
     * de Spring lo mandan como JSON con comillas ("ADMIN") y otras como
     * texto plano sin comillas (ADMIN). Este metodo funciona con los dos
     * casos, sin depender de que sea JSON valido.
     */
    public static String getTexto(String path) {
        HttpResponse<String> response = enviar(HttpRequest.newBuilder(URI.create(BASE_URL + path)).GET().build());
        String cuerpo = response.body() == null ? "" : response.body().trim();
        if (cuerpo.startsWith("\"") && cuerpo.endsWith("\"") && cuerpo.length() >= 2) {
            cuerpo = cuerpo.substring(1, cuerpo.length() - 1); // le saca las comillas si vino como JSON
        }
        return cuerpo;
    }

    public static <T> T get(String path, TypeReference<T> tipo) {
        return enviarYParsear(HttpRequest.newBuilder(URI.create(BASE_URL + path)).GET().build(), tipo);
    }

    public static <T> T post(String path, Object cuerpo, Class<T> tipoRespuesta) {
        return enviarYParsear(construirConCuerpo(path, "POST", cuerpo), tipoRespuesta);
    }

    public static void put(String path, Object cuerpo) {
        enviarSinRespuesta(construirConCuerpo(path, "PUT", cuerpo));
    }

    public static void patch(String path) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + path))
                .method("PATCH", HttpRequest.BodyPublishers.noBody())
                .build();
        enviarSinRespuesta(request);
    }

    public static void delete(String path) {
        enviarSinRespuesta(HttpRequest.newBuilder(URI.create(BASE_URL + path)).DELETE().build());
    }

    private static HttpRequest construirConCuerpo(String path, String metodo, Object cuerpo) {
        try {
            String json = MAPPER.writeValueAsString(cuerpo);
            System.out.println("=== JSON enviado a " + metodo + " " + path + " ===");
            System.out.println(json);
            System.out.println("=======================================");
            return HttpRequest.newBuilder(URI.create(BASE_URL + path))
                    .header("Content-Type", "application/json")
                    .method(metodo, HttpRequest.BodyPublishers.ofString(json))
                    .build();
        } catch (Exception e) {
            throw new ApiException("No se pudo armar el pedido: " + e.getMessage());
        }
    }

    private static <T> T enviarYParsear(HttpRequest request, Class<T> tipo) {
        HttpResponse<String> response = enviar(request);
        try {
            if (response.body() == null || response.body().isBlank()) return null;
            return MAPPER.readValue(response.body(), tipo);
        } catch (IOException e) {
            throw new ApiException("El servidor respondio algo que no pudimos interpretar.");
        }
    }

    private static <T> T enviarYParsear(HttpRequest request, TypeReference<T> tipo) {
        HttpResponse<String> response = enviar(request);
        try {
            return MAPPER.readValue(response.body(), tipo);
        } catch (IOException e) {
            throw new ApiException("El servidor respondio algo que no pudimos interpretar.");
        }
    }

    private static void enviarSinRespuesta(HttpRequest request) { enviar(request); }

    private static HttpResponse<String> enviar(HttpRequest request) {
        try {
            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            verificarError(response);
            return response;
        } catch (ApiException e) {
            throw e;
        } catch (IOException | InterruptedException e) {
            throw new ApiException("No se pudo conectar con el servidor. ¿Esta corriendo en " + BASE_URL + "?");
        }
    }

    private static void verificarError(HttpResponse<String> response) {
        int codigo = response.statusCode();
        if (codigo >= 200 && codigo < 300) return;
        String mensaje = "Error del servidor (codigo " + codigo + ")";
        try {
            Map<?, ?> cuerpo = MAPPER.readValue(response.body(), Map.class);
            if (cuerpo.get("error") != null) mensaje = cuerpo.get("error").toString();
        } catch (Exception ignored) { }
        throw new ApiException(mensaje);
    }
}
