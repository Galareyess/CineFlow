package com.proyecto.gestorcine.swing.modelo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Butaca {
    private ButacaId id;
    private boolean estado; // true = ocupada, false = libre

    public Butaca() {}
    public Butaca(char fila, int numero, boolean estado) {
        this.id = new ButacaId(fila, numero);
        this.estado = estado;
    }

    public ButacaId getId() { return id; }
    public void setId(ButacaId id) { this.id = id; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
}
