package com.proyecto.gestorcine.swing.modelo;

// Clase minima solo para el alta de administrador: si reusaramos Cliente
// (que tiene el campo "dni"), el backend podria rechazar el JSON por
// tener una propiedad que Administrador no reconoce.
public class NuevoAdmin {
    private String usuario;
    private int contrasena;

    public NuevoAdmin() {}
    public NuevoAdmin(String usuario, int contrasena) {
        this.usuario = usuario; this.contrasena = contrasena;
    }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public int getContrasena() { return contrasena; }
    public void setContrasena(int contrasena) { this.contrasena = contrasena; }
}
