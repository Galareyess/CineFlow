package com.proyecto.gestorcine.swing.modelo;

public class DatosTarjeta {
    private String numero;
    private String titular;
    private String vencimiento;
    private String cvv;
    private int fondos;

    public DatosTarjeta() {}
    public DatosTarjeta(String numero, String titular, String vencimiento, String cvv, int fondos) {
        this.numero = numero; this.titular = titular; this.vencimiento = vencimiento;
        this.cvv = cvv; this.fondos = fondos;
    }

    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }
    public String getTitular() { return titular; }
    public void setTitular(String titular) { this.titular = titular; }
    public String getVencimiento() { return vencimiento; }
    public void setVencimiento(String vencimiento) { this.vencimiento = vencimiento; }
    public String getCvv() { return cvv; }
    public void setCvv(String cvv) { this.cvv = cvv; }
    public int getFondos() { return fondos; }
    public void setFondos(int fondos) { this.fondos = fondos; }
}
