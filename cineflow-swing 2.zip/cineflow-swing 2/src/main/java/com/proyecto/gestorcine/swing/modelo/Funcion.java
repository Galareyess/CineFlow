package com.proyecto.gestorcine.swing.modelo;

import java.time.LocalDateTime;

public class Funcion {
    private Integer codigoFuncion;
    private Pelicula pelicula;
    private Sala sala;
    private LocalDateTime horario;
    private boolean esSubtitulada;

    public Funcion() {}
    public Funcion(Integer codigoFuncion, Pelicula pelicula, Sala sala, LocalDateTime horario, boolean esSubtitulada) {
        this.codigoFuncion = codigoFuncion; this.pelicula = pelicula; this.sala = sala;
        this.horario = horario; this.esSubtitulada = esSubtitulada;
    }

    public Integer getCodigoFuncion() { return codigoFuncion; }
    public void setCodigoFuncion(Integer codigoFuncion) { this.codigoFuncion = codigoFuncion; }
    public Pelicula getPelicula() { return pelicula; }
    public void setPelicula(Pelicula pelicula) { this.pelicula = pelicula; }
    public Sala getSala() { return sala; }
    public void setSala(Sala sala) { this.sala = sala; }
    public LocalDateTime getHorario() { return horario; }
    public void setHorario(LocalDateTime horario) { this.horario = horario; }
    public boolean isEsSubtitulada() { return esSubtitulada; }
    public void setEsSubtitulada(boolean esSubtitulada) { this.esSubtitulada = esSubtitulada; }
}
