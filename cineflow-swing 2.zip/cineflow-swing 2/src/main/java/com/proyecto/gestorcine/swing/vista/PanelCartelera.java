package com.proyecto.gestorcine.swing.vista;

import com.fasterxml.jackson.core.type.TypeReference;
import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.Funcion;
import com.proyecto.gestorcine.swing.modelo.Pelicula;
import com.proyecto.gestorcine.swing.modelo.Sala;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class PanelCartelera extends JPanel {

    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new String[]{"Codigo", "Pelicula", "Sala", "Horario", "Subtitulada"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable tabla = new JTable(modeloTabla);

    private final JComboBox<String> comboPelicula = new JComboBox<>();
    private final JComboBox<String> comboSala = new JComboBox<>();
    private final JTextField campoHorario = new JTextField(14);
    private final JCheckBox checkSubtitulada = new JCheckBox("Subtitulada");

    private List<Pelicula> peliculasCache = new ArrayList<>();
    private List<Sala> salasCache = new ArrayList<>();

    public PanelCartelera() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(construirFormulario(), BorderLayout.SOUTH);

        cargarCombos();
        cargarCartelera();
    }

    private JPanel construirFormulario() {
        JPanel formulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);

        gbc.gridx = 0; gbc.gridy = 0; formulario.add(new JLabel("Pelicula"), gbc);
        gbc.gridx = 1; formulario.add(new JLabel("Sala"), gbc);
        gbc.gridx = 2; formulario.add(new JLabel("Horario (dd/MM/yyyy HH:mm)"), gbc);
        gbc.gridx = 3; formulario.add(checkSubtitulada, gbc);

        gbc.gridy = 1;
        gbc.gridx = 0; formulario.add(comboPelicula, gbc);
        gbc.gridx = 1; formulario.add(comboSala, gbc);
        gbc.gridx = 2; formulario.add(campoHorario, gbc);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton botonAgregar = new JButton("Agregar funcion");
        JButton botonEliminar = new JButton("Eliminar seleccionada");
        JButton botonRecargarListas = new JButton("Recargar peliculas/salas");
        JButton botonRefrescar = new JButton("Refrescar cartelera");
        botones.add(botonAgregar); botones.add(botonEliminar); botones.add(botonRecargarListas); botones.add(botonRefrescar);

        botonAgregar.addActionListener(e -> agregarFuncion());
        botonEliminar.addActionListener(e -> eliminarFuncion());
        botonRecargarListas.addActionListener(e -> cargarCombos());
        botonRefrescar.addActionListener(e -> cargarCartelera());

        JPanel sur = new JPanel(new BorderLayout());
        sur.add(formulario, BorderLayout.NORTH);
        sur.add(botones, BorderLayout.SOUTH);
        return sur;
    }

    private void cargarCombos() {
        try {
            peliculasCache = ApiClient.get("/api/peliculas", new TypeReference<List<Pelicula>>() {});
            comboPelicula.removeAllItems();
            for (Pelicula p : peliculasCache) comboPelicula.addItem(p.getCodigoPelicula() + " - " + p.getNombre());
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar peliculas", JOptionPane.ERROR_MESSAGE);
        }
        try {
            salasCache = ApiClient.get("/api/salas", new TypeReference<List<Sala>>() {});
            comboSala.removeAllItems();
            for (Sala s : salasCache) comboSala.addItem(s.getNumeroSala() + " - " + s.getFormato());
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar salas", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarCartelera() {
        try {
            List<Funcion> funciones = ApiClient.get("/api/cartelera", new TypeReference<List<Funcion>>() {});
            modeloTabla.setRowCount(0);
            for (Funcion f : funciones) {
                modeloTabla.addRow(new Object[]{
                        f.getCodigoFuncion(),
                        f.getPelicula() != null ? f.getPelicula().getNombre() : "-",
                        f.getSala() != null ? f.getSala().getNumeroSala() : "-",
                        f.getHorario() != null ? f.getHorario().format(FORMATO_FECHA) : "-",
                        f.isEsSubtitulada() ? "Si" : "No"
                });
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar la cartelera", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarFuncion() {
        int idxPelicula = comboPelicula.getSelectedIndex();
        int idxSala = comboSala.getSelectedIndex();
        if (idxPelicula == -1 || idxSala == -1) {
            JOptionPane.showMessageDialog(this, "Cargá al menos una pelicula y una sala primero (pestañas correspondientes).", "Faltan datos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            LocalDateTime horario = LocalDateTime.parse(campoHorario.getText().trim(), FORMATO_FECHA);
            Pelicula peliculaRef = peliculasCache.get(idxPelicula);
            Sala salaRef = salasCache.get(idxSala);

            Funcion nueva = new Funcion(null, peliculaRef, salaRef, horario, checkSubtitulada.isSelected());
            ApiClient.post("/api/cartelera", nueva, Funcion.class);
            campoHorario.setText("");
            checkSubtitulada.setSelected(false);
            cargarCartelera();
        } catch (java.time.format.DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "Fecha invalida. Usa el formato dd/MM/yyyy HH:mm.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo agregar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarFuncion() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una funcion primero.", "Nada seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        try {
            ApiClient.delete("/api/cartelera/" + codigo);
            cargarCartelera();
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }
}
