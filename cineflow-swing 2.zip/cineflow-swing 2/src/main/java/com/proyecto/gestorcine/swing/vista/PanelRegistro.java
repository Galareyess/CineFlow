package com.proyecto.gestorcine.swing.vista;

import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.Cliente;

import javax.swing.*;
import java.awt.*;

public class PanelRegistro extends JPanel {

    private final VentanaPrincipal ventana;
    private final JTextField campoUsuario = new JTextField(18);
    private final JPasswordField campoContrasena = new JPasswordField(18);
    private final JTextField campoDni = new JTextField(18);

    public PanelRegistro(VentanaPrincipal ventana) {
        this.ventana = ventana;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel titulo = new JLabel("Registro de cliente");
        titulo.setFont(new Font("Serif", Font.BOLD, 22));
        add(titulo, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;
        add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        add(campoUsuario, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Contrasena:"), gbc);
        gbc.gridx = 1;
        add(campoContrasena, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("DNI:"), gbc);
        gbc.gridx = 1;
        add(campoDni, gbc);

        JButton botonRegistrar = new JButton("Registrarme");
        JButton botonVolver = new JButton("Volver al login");

        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        add(botonRegistrar, gbc);
        gbc.gridy++;
        add(botonVolver, gbc);

        botonRegistrar.addActionListener(e -> registrar());
        botonVolver.addActionListener(e -> ventana.mostrarPantalla("LOGIN"));
    }

    private void registrar() {
        String usuario = campoUsuario.getText().trim();
        String contrasenaTexto = new String(campoContrasena.getPassword());
        String dni = campoDni.getText().trim();

        if (usuario.isEmpty() || contrasenaTexto.isEmpty() || dni.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa todos los campos.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int contrasena;
        try {
            contrasena = Integer.parseInt(contrasenaTexto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La contrasena debe ser numerica.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ApiClient.post("/api/usuarios/clientes", new Cliente(usuario, contrasena, dni), Cliente.class);
            JOptionPane.showMessageDialog(this, "Cuenta creada. Ya podes iniciar sesion.", "Listo", JOptionPane.INFORMATION_MESSAGE);
            campoUsuario.setText(""); campoContrasena.setText(""); campoDni.setText("");
            ventana.mostrarPantalla("LOGIN");
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo registrar", JOptionPane.ERROR_MESSAGE);
        }
    }
}
