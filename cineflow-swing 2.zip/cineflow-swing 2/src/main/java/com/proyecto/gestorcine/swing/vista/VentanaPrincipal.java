package com.proyecto.gestorcine.swing.vista;

import javax.swing.*;
import java.awt.*;

public class VentanaPrincipal extends JFrame {

    private final CardLayout cardLayout = new CardLayout();
    private final JPanel panelContenedor = new JPanel(cardLayout);

    public VentanaPrincipal() {
        super("CineFlow");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);

        panelContenedor.add(new PanelLogin(this), "LOGIN");
        panelContenedor.add(new PanelRegistro(this), "REGISTRO");

        add(panelContenedor);
    }

    public void mostrarPantalla(String nombre) {
        cardLayout.show(panelContenedor, nombre);
    }

    public void irAPanelAdmin() {
        panelContenedor.add(new PanelAdmin(this), "ADMIN");
        mostrarPantalla("ADMIN");
    }

    public void irAPanelCliente(String usuario) {
        panelContenedor.add(new PanelCliente(this, usuario), "CLIENTE");
        mostrarPantalla("CLIENTE");
    }

    public void cerrarSesion() {
        mostrarPantalla("LOGIN");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}
