package com.proyecto.gestorcine.swing.vista;

import com.fasterxml.jackson.core.type.TypeReference;
import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PanelCliente extends JPanel {

    private final String usuario;
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final DefaultTableModel modeloCartelera = new DefaultTableModel(
            new String[]{"Codigo Funcion", "Pelicula", "Sala", "Horario", "Subtitulada"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable tablaCartelera = new JTable(modeloCartelera);

    public PanelCliente(VentanaPrincipal ventana, String usuario) {
        this.usuario = usuario;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel barraSuperior = new JPanel(new BorderLayout());
        JLabel titulo = new JLabel("Bienvenido, " + usuario);
        titulo.setFont(new Font("Serif", Font.BOLD, 20));
        JButton botonCerrarSesion = new JButton("Cerrar sesion");
        botonCerrarSesion.addActionListener(e -> ventana.cerrarSesion());
        barraSuperior.add(titulo, BorderLayout.WEST);
        barraSuperior.add(botonCerrarSesion, BorderLayout.EAST);
        add(barraSuperior, BorderLayout.NORTH);

        add(new JScrollPane(tablaCartelera), BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton botonRefrescar = new JButton("Refrescar cartelera");
        JButton botonReservar = new JButton("Reservar entrada para la funcion seleccionada");
        panelBotones.add(botonRefrescar);
        panelBotones.add(botonReservar);
        add(panelBotones, BorderLayout.SOUTH);

        botonRefrescar.addActionListener(e -> cargarCartelera());
        botonReservar.addActionListener(e -> reservar());

        cargarCartelera();
    }

    private void cargarCartelera() {
        try {
            List<Funcion> funciones = ApiClient.get("/api/cartelera", new TypeReference<List<Funcion>>() {});
            modeloCartelera.setRowCount(0);
            for (Funcion f : funciones) {
                modeloCartelera.addRow(new Object[]{
                        f.getCodigoFuncion(),
                        f.getPelicula() != null ? f.getPelicula().getNombre() : "-",
                        f.getSala() != null ? f.getSala().getNumeroSala() : "-",
                        f.getHorario() != null ? f.getHorario().format(FORMATO_FECHA) : "-",
                        f.isEsSubtitulada() ? "Si" : "No"
                });
            }
            if (funciones.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Todavia no hay funciones cargadas. Pedile a un administrador que cree\n" +
                        "peliculas, salas y funciones (esta version simple del Swing solo\n" +
                        "administra peliculas; el resto se puede cargar por Postman/Swagger).",
                        "Cartelera vacia", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar la cartelera", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Antes de pagar, le pregunta al cliente si quiere sumar productos
     * del kiosco a la misma compra (DetalleProducto en el backend).
     * Es opcional: si dice que no, la reserva sigue solo con tickets.
     */
    private void agregarProductosDeKiosco(Reserva reserva) {
        int quiere = JOptionPane.showConfirmDialog(this,
                "¿Queres agregar productos del kiosco a esta compra?", "Kiosco", JOptionPane.YES_NO_OPTION);
        if (quiere != JOptionPane.YES_OPTION) return;

        List<Producto> productos;
        try {
            productos = ApiClient.get("/api/productos", new TypeReference<List<Producto>>() {});
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar el kiosco", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (productos.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todavia no hay productos cargados.", "Kiosco vacio", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        StringBuilder lista = new StringBuilder("Productos disponibles:\n");
        for (Producto p : productos) {
            lista.append(p.getCodigoProducto()).append(" - ").append(p.getNombre())
                    .append(" ($").append(p.getPrecio()).append(", stock: ").append(p.getStock()).append(")\n");
        }

        boolean seguirAgregando = true;
        while (seguirAgregando) {
            String codigoTexto = JOptionPane.showInputDialog(this, lista + "\nCodigo del producto a agregar (cancelar para terminar):");
            if (codigoTexto == null || codigoTexto.isBlank()) break;
            String cantidadTexto = JOptionPane.showInputDialog(this, "Cantidad:");
            if (cantidadTexto == null) break;
            try {
                int codigoProducto = Integer.parseInt(codigoTexto.trim());
                int cantidad = Integer.parseInt(cantidadTexto.trim());
                reserva.getDetallesProducto().add(new DetalleProducto(codigoProducto, cantidad));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Codigo y cantidad deben ser numeros.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
            }
            int otroMas = JOptionPane.showConfirmDialog(this, "¿Agregar otro producto?", "Kiosco", JOptionPane.YES_NO_OPTION);
            seguirAgregando = otroMas == JOptionPane.YES_OPTION;
        }
    }

    private void reservar() {
        int fila = tablaCartelera.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una funcion de la tabla primero.", "Nada seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int codigoFuncion = (int) modeloCartelera.getValueAt(fila, 0);

        try {
            String filaTexto = JOptionPane.showInputDialog(this, "Fila de la butaca (una letra):");
            if (filaTexto == null || filaTexto.isBlank()) return;
            String numeroTexto = JOptionPane.showInputDialog(this, "Numero de butaca:");
            if (numeroTexto == null) return;

            char filaButaca = filaTexto.trim().toUpperCase().charAt(0);
            int numeroButaca = Integer.parseInt(numeroTexto.trim());

            // Datos de tarjeta: el backend simula el pago (PagoService), no
            // hay integracion real con ningun banco.
            String numeroTarjeta = JOptionPane.showInputDialog(this, "Numero de tarjeta (16 digitos):", "1111222233334444");
            if (numeroTarjeta == null) return;
            String titular = JOptionPane.showInputDialog(this, "Titular de la tarjeta:", usuario);
            if (titular == null) return;
            String vencimiento = JOptionPane.showInputDialog(this, "Vencimiento (MM/AA):", "12/30");
            if (vencimiento == null) return;
            String cvv = JOptionPane.showInputDialog(this, "CVV (3 digitos):", "123");
            if (cvv == null) return;

            Funcion funcionRef = new Funcion(codigoFuncion, null, null, null, false);
            Ticket ticket = new Ticket(funcionRef, new Ticket.ButacaRef(filaButaca, numeroButaca));

            Reserva reserva = new Reserva(new ClienteRef(usuario), LocalDateTime.now());
            reserva.getTickets().add(ticket);
            agregarProductosDeKiosco(reserva);

            DatosTarjeta tarjeta = new DatosTarjeta(numeroTarjeta.trim(), titular.trim(), vencimiento.trim(), cvv.trim(), 999999);

            VentaRequest request = new VentaRequest(reserva, tarjeta);
            ApiClient.post("/api/ventas", request, Reserva.class);

            JOptionPane.showMessageDialog(this, "¡Reserva confirmada!", "Listo", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El numero de butaca debe ser un numero.", "Datos invalidos", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo completar la reserva", JOptionPane.ERROR_MESSAGE);
        }
    }
}
