package com.proyecto.gestorcine.swing.modelo;

public class Cliente {
    private String usuario;
    private int contrasena;
    private String dni;

    public Cliente() {}
    public Cliente(String usuario, int contrasena, String dni) {
        this.usuario = usuario; this.contrasena = contrasena; this.dni = dni;
    }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public int getContrasena() { return contrasena; }
    public void setContrasena(int contrasena) { this.contrasena = contrasena; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
}
