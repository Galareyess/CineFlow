package com.proyecto.gestorcine.swing.modelo;

public class ClienteRef {
    private String usuario;
    public ClienteRef() {}
    public ClienteRef(String usuario) { this.usuario = usuario; }
    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
}
