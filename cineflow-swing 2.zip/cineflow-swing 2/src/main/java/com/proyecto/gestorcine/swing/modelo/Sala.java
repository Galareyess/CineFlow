package com.proyecto.gestorcine.swing.modelo;

public class Sala {
    private Integer numeroSala;
    private int capacidad;
    private boolean estado;
    private String formato;

    public Sala() {}
    public Sala(Integer numeroSala, int capacidad, boolean estado, String formato) {
        this.numeroSala = numeroSala; this.capacidad = capacidad;
        this.estado = estado; this.formato = formato;
    }

    public Integer getNumeroSala() { return numeroSala; }
    public void setNumeroSala(Integer numeroSala) { this.numeroSala = numeroSala; }
    public int getCapacidad() { return capacidad; }
    public void setCapacidad(int capacidad) { this.capacidad = capacidad; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
    public String getFormato() { return formato; }
    public void setFormato(String formato) { this.formato = formato; }
}
