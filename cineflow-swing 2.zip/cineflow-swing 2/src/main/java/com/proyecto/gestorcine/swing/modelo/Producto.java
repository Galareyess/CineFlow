package com.proyecto.gestorcine.swing.modelo;

import java.math.BigDecimal;

public class Producto {
    private Integer codigoProducto;
    private String nombre;
    private BigDecimal precio;
    private int stock;

    public Producto() {}
    public Producto(Integer codigoProducto, String nombre, BigDecimal precio, int stock) {
        this.codigoProducto = codigoProducto; this.nombre = nombre;
        this.precio = precio; this.stock = stock;
    }

    public Integer getCodigoProducto() { return codigoProducto; }
    public void setCodigoProducto(Integer codigoProducto) { this.codigoProducto = codigoProducto; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
}
