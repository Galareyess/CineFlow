package com.proyecto.gestorcine.swing.vista;

import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.NuevoAdmin;

import javax.swing.*;
import java.awt.*;

public class PanelLogin extends JPanel {

    private final VentanaPrincipal ventana;
    private final JTextField campoUsuario = new JTextField(18);
    private final JPasswordField campoContrasena = new JPasswordField(18);

    public PanelLogin(VentanaPrincipal ventana) {
        this.ventana = ventana;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel titulo = new JLabel("CineFlow");
        titulo.setFont(new Font("Serif", Font.BOLD, 28));
        add(titulo, gbc);

        gbc.gridwidth = 1;
        gbc.gridy++;
        add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;
        add(campoUsuario, gbc);

        gbc.gridx = 0; gbc.gridy++;
        add(new JLabel("Contrasena:"), gbc);
        gbc.gridx = 1;
        add(campoContrasena, gbc);

        JButton botonIngresar = new JButton("Iniciar sesion");
        JButton botonRegistrarse = new JButton("Registrarse como cliente");

        gbc.gridx = 0; gbc.gridy++; gbc.gridwidth = 2;
        add(botonIngresar, gbc);
        gbc.gridy++;
        add(botonRegistrarse, gbc);

        // El backend actual no tiene un admin precargado (no hay
        // AdminBootstrap como en versiones anteriores). Este boton es
        // un atajo de desarrollo para crear el primer admin desde la
        // propia app, ya que POST /api/usuarios/administradores todavia
        // no tiene ninguna restriccion de seguridad. El dia que agreguen
        // Spring Security, ESTE BOTON HAY QUE SACARLO del login publico.
        JButton botonCrearAdmin = new JButton("Crear administrador (solo desarrollo)");
        gbc.gridy++;
        add(botonCrearAdmin, gbc);

        botonIngresar.addActionListener(e -> iniciarSesion());
        botonRegistrarse.addActionListener(e -> ventana.mostrarPantalla("REGISTRO"));
        botonCrearAdmin.addActionListener(e -> crearAdminDeDesarrollo());
        campoContrasena.addActionListener(e -> iniciarSesion());
    }

    private void iniciarSesion() {
        String usuario = campoUsuario.getText().trim();
        String contrasenaTexto = new String(campoContrasena.getPassword());

        if (usuario.isEmpty() || contrasenaTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Completa usuario y contrasena.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int contrasena;
        try {
            contrasena = Integer.parseInt(contrasenaTexto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La contrasena debe ser numerica.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String path = "/api/usuarios/login?usuario=" + usuario + "&contrasena=" + contrasena;
            String tipo = ApiClient.getTexto(path);
            campoContrasena.setText("");
            if ("ADMIN".equals(tipo)) {
                ventana.irAPanelAdmin();
            } else {
                ventana.irAPanelCliente(usuario);
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo iniciar sesion", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void crearAdminDeDesarrollo() {
        String usuario = JOptionPane.showInputDialog(this, "Usuario para el nuevo admin:");
        if (usuario == null || usuario.isBlank()) return;
        String contrasenaTexto = JOptionPane.showInputDialog(this, "Contrasena (numerica):");
        if (contrasenaTexto == null) return;
        try {
            int contrasena = Integer.parseInt(contrasenaTexto.trim());
            NuevoAdmin admin = new NuevoAdmin(usuario.trim(), contrasena);
            ApiClient.post("/api/usuarios/administradores", admin, Object.class);
            JOptionPane.showMessageDialog(this, "Administrador creado. Ya podes iniciar sesion.", "Listo", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La contrasena debe ser numerica.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo crear", JOptionPane.ERROR_MESSAGE);
        }
    }
}
