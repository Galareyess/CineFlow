package com.proyecto.gestorcine.swing.vista;

import com.fasterxml.jackson.core.type.TypeReference;
import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class PanelKiosco extends JPanel {

    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new String[]{"Codigo", "Nombre", "Precio", "Stock"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable tabla = new JTable(modeloTabla);

    private final JTextField campoNombre = new JTextField(14);
    private final JTextField campoPrecio = new JTextField(8);
    private final JTextField campoStock = new JTextField(6);

    public PanelKiosco() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(construirFormulario(), BorderLayout.SOUTH);

        cargarProductos();
    }

    private JPanel construirFormulario() {
        JPanel formulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);

        gbc.gridy = 0;
        gbc.gridx = 0; formulario.add(new JLabel("Nombre"), gbc);
        gbc.gridx = 1; formulario.add(new JLabel("Precio"), gbc);
        gbc.gridx = 2; formulario.add(new JLabel("Stock inicial"), gbc);
        gbc.gridy = 1;
        gbc.gridx = 0; formulario.add(campoNombre, gbc);
        gbc.gridx = 1; formulario.add(campoPrecio, gbc);
        gbc.gridx = 2; formulario.add(campoStock, gbc);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton botonAgregar = new JButton("Agregar producto");
        JButton botonEliminar = new JButton("Eliminar seleccionado");
        JButton botonDescontarStock = new JButton("Descontar stock");
        JButton botonRefrescar = new JButton("Refrescar");
        botones.add(botonAgregar); botones.add(botonEliminar); botones.add(botonDescontarStock); botones.add(botonRefrescar);

        botonAgregar.addActionListener(e -> agregarProducto());
        botonEliminar.addActionListener(e -> eliminarProducto());
        botonDescontarStock.addActionListener(e -> descontarStock());
        botonRefrescar.addActionListener(e -> cargarProductos());

        JPanel sur = new JPanel(new BorderLayout());
        sur.add(formulario, BorderLayout.NORTH);
        sur.add(botones, BorderLayout.SOUTH);
        return sur;
    }

    private void cargarProductos() {
        try {
            List<Producto> productos = ApiClient.get("/api/productos", new TypeReference<List<Producto>>() {});
            modeloTabla.setRowCount(0);
            for (Producto p : productos) {
                modeloTabla.addRow(new Object[]{p.getCodigoProducto(), p.getNombre(), p.getPrecio(), p.getStock()});
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar productos", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarProducto() {
        try {
            String nombre = campoNombre.getText().trim();
            BigDecimal precio = new BigDecimal(campoPrecio.getText().trim());
            int stock = Integer.parseInt(campoStock.getText().trim());
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede estar vacio.", "Dato faltante", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Producto nuevo = new Producto(null, nombre, precio, stock);
            ApiClient.post("/api/productos", nuevo, Producto.class);
            campoNombre.setText(""); campoPrecio.setText(""); campoStock.setText("");
            cargarProductos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio y stock deben ser numeros validos.", "Datos invalidos", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo agregar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarProducto() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto primero.", "Nada seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        try {
            ApiClient.delete("/api/productos/" + codigo);
            cargarProductos();
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void descontarStock() {
        int fila = tabla.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un producto primero.", "Nada seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int codigo = (int) modeloTabla.getValueAt(fila, 0);
        String cantidadTexto = JOptionPane.showInputDialog(this, "¿Cuanto stock descontar?");
        if (cantidadTexto == null) return;
        try {
            int cantidad = Integer.parseInt(cantidadTexto.trim());
            ApiClient.patch("/api/productos/" + codigo + "/stock?cantidad=" + cantidad);
            cargarProductos();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cantidad debe ser un numero.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo descontar", JOptionPane.ERROR_MESSAGE);
        }
    }
}
