package com.proyecto.gestorcine.swing.vista;

import javax.swing.*;
import java.awt.*;

public class PanelAdmin extends JPanel {

    public PanelAdmin(VentanaPrincipal ventana) {
        setLayout(new BorderLayout());

        JPanel barraSuperior = new JPanel(new BorderLayout());
        barraSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel titulo = new JLabel("Panel de administrador");
        titulo.setFont(new Font("Serif", Font.BOLD, 20));
        JButton botonCerrarSesion = new JButton("Cerrar sesion");
        botonCerrarSesion.addActionListener(e -> ventana.cerrarSesion());
        barraSuperior.add(titulo, BorderLayout.WEST);
        barraSuperior.add(botonCerrarSesion, BorderLayout.EAST);
        add(barraSuperior, BorderLayout.NORTH);

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("Peliculas", new PanelPeliculas());
        pestanas.addTab("Salas / Butacas", new PanelSalas());
        pestanas.addTab("Cartelera", new PanelCartelera());
        pestanas.addTab("Kiosco", new PanelKiosco());
        add(pestanas, BorderLayout.CENTER);
    }
}
