package com.proyecto.gestorcine.swing.modelo;

public class Pelicula {
    public static final String[] GENEROS = {
            "ACCION", "COMEDIA", "DRAMA", "TERROR", "CIENCIA_FICCION",
            "ANIMACION", "ROMANCE", "SUSPENSO", "MUSICAL"
    };

    private Integer codigoPelicula;
    private String nombre;
    private String genero;
    private int duracion;
    private String director;
    private String actoresPrincipales;
    private String sinopsis;

    public Pelicula() {}
    public Pelicula(Integer codigoPelicula, String nombre, String genero, int duracion,
                     String director, String actoresPrincipales, String sinopsis) {
        this.codigoPelicula = codigoPelicula; this.nombre = nombre; this.genero = genero;
        this.duracion = duracion; this.director = director;
        this.actoresPrincipales = actoresPrincipales; this.sinopsis = sinopsis;
    }

    public Integer getCodigoPelicula() { return codigoPelicula; }
    public void setCodigoPelicula(Integer codigoPelicula) { this.codigoPelicula = codigoPelicula; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }
    public int getDuracion() { return duracion; }
    public void setDuracion(int duracion) { this.duracion = duracion; }
    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }
    public String getActoresPrincipales() { return actoresPrincipales; }
    public void setActoresPrincipales(String actoresPrincipales) { this.actoresPrincipales = actoresPrincipales; }
    public String getSinopsis() { return sinopsis; }
    public void setSinopsis(String sinopsis) { this.sinopsis = sinopsis; }
}
