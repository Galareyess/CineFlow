package com.proyecto.gestorcine.swing.vista;

import com.fasterxml.jackson.core.type.TypeReference;
import com.proyecto.gestorcine.swing.controlador.ApiClient;
import com.proyecto.gestorcine.swing.modelo.Butaca;
import com.proyecto.gestorcine.swing.modelo.Sala;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class PanelSalas extends JPanel {

    public PanelSalas() {
        setLayout(new BorderLayout());
        JTabbedPane subPestanas = new JTabbedPane();
        subPestanas.addTab("Salas", construirPanelSalas());
        subPestanas.addTab("Butacas", construirPanelGrilla());
        add(subPestanas, BorderLayout.CENTER);
    }

    // ---------------------- SALAS ----------------------

    private final DefaultTableModel modeloSalas = new DefaultTableModel(
            new String[]{"Numero", "Capacidad", "Llena", "Formato"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable tablaSalas = new JTable(modeloSalas);
    private final JTextField campoNumeroSala = new JTextField(5);
    private final JTextField campoCapacidad = new JTextField(5);
    private final JCheckBox checkLlena = new JCheckBox("Llena");
    private final JTextField campoFormato = new JTextField(8);

    private JPanel construirPanelSalas() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(new JScrollPane(tablaSalas), BorderLayout.CENTER);

        JPanel formulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);

        String[] etiquetas = {"Numero de sala", "Capacidad", "Formato (2D/3D/4D)"};
        JComponent[] campos = {campoNumeroSala, campoCapacidad, campoFormato};
        gbc.gridy = 0;
        for (int i = 0; i < etiquetas.length; i++) { gbc.gridx = i; formulario.add(new JLabel(etiquetas[i]), gbc); }
        gbc.gridy = 1;
        for (int i = 0; i < campos.length; i++) { gbc.gridx = i; formulario.add(campos[i], gbc); }
        gbc.gridx = campos.length; formulario.add(checkLlena, gbc);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton botonAgregar = new JButton("Agregar sala");
        JButton botonEliminar = new JButton("Eliminar seleccionada");
        JButton botonRefrescar = new JButton("Refrescar");
        botones.add(botonAgregar); botones.add(botonEliminar); botones.add(botonRefrescar);

        botonAgregar.addActionListener(e -> agregarSala());
        botonEliminar.addActionListener(e -> eliminarSala());
        botonRefrescar.addActionListener(e -> cargarSalas());

        JPanel sur = new JPanel(new BorderLayout());
        sur.add(formulario, BorderLayout.NORTH);
        sur.add(botones, BorderLayout.SOUTH);
        panel.add(sur, BorderLayout.SOUTH);

        cargarSalas();
        return panel;
    }

    private void cargarSalas() {
        try {
            List<Sala> salas = ApiClient.get("/api/salas", new TypeReference<List<Sala>>() {});
            modeloSalas.setRowCount(0);
            for (Sala s : salas) {
                modeloSalas.addRow(new Object[]{s.getNumeroSala(), s.getCapacidad(), s.isEstado() ? "Si" : "No", s.getFormato()});
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar salas", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void agregarSala() {
        try {
            int numero = Integer.parseInt(campoNumeroSala.getText().trim());
            int capacidad = Integer.parseInt(campoCapacidad.getText().trim());
            Sala nueva = new Sala(numero, capacidad, checkLlena.isSelected(), campoFormato.getText().trim());
            ApiClient.post("/api/salas", nueva, Sala.class);
            campoNumeroSala.setText(""); campoCapacidad.setText(""); campoFormato.setText(""); checkLlena.setSelected(false);
            cargarSalas();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Numero de sala y capacidad deben ser numeros.", "Datos invalidos", JOptionPane.WARNING_MESSAGE);
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo agregar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarSala() {
        int fila = tablaSalas.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una sala primero.", "Nada seleccionado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int numero = (int) modeloSalas.getValueAt(fila, 0);
        try {
            ApiClient.delete("/api/salas/" + numero);
            cargarSalas();
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ---------------------- BUTACAS (cuadricula) ----------------------
    private final JComboBox<String> comboSalaGrilla = new JComboBox<>();
    private final JTextField campoAsientosPorFila = new JTextField("10", 4);
    private final JPanel panelGrilla = new JPanel();
    private List<Sala> salasCacheGrilla = new java.util.ArrayList<>();
    private List<Butaca> butacasCacheGrilla = new java.util.ArrayList<>();

    private JPanel construirPanelGrilla() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel controles = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controles.add(new JLabel("Sala:"));
        controles.add(comboSalaGrilla);
        controles.add(new JLabel("Asientos por fila:"));
        controles.add(campoAsientosPorFila);
        JButton botonGenerar = new JButton("Generar cuadricula");
        controles.add(botonGenerar);
        panel.add(controles, BorderLayout.NORTH);

        panelGrilla.setLayout(new GridLayout(0, 1));
        panel.add(new JScrollPane(panelGrilla), BorderLayout.CENTER);

        JLabel leyenda = new JLabel("Gris = no creada (click crea) | Verde = libre (click pregunta si borrar) | Rojo = ocupada");
        panel.add(leyenda, BorderLayout.SOUTH);

        botonGenerar.addActionListener(e -> generarCuadricula());
        cargarSalasParaGrilla();
        return panel;
    }

    private void cargarSalasParaGrilla() {
        try {
            salasCacheGrilla = ApiClient.get("/api/salas", new TypeReference<List<Sala>>() {});
            comboSalaGrilla.removeAllItems();
            for (Sala s : salasCacheGrilla) {
                comboSalaGrilla.addItem(s.getNumeroSala() + " - " + s.getFormato() + " (cap. " + s.getCapacidad() + ")");
            }
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar salas", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void generarCuadricula() {
        int idx = comboSalaGrilla.getSelectedIndex();
        if (idx == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una sala primero.", "Falta la sala", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Sala salaElegida = salasCacheGrilla.get(idx);

        int asientosPorFila;
        try {
            asientosPorFila = Integer.parseInt(campoAsientosPorFila.getText().trim());
            if (asientosPorFila <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Asientos por fila debe ser un numero mayor a 0.", "Dato invalido", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int capacidad = salaElegida.getCapacidad();
        int filas = (int) Math.ceil(capacidad / (double) asientosPorFila);
        if (filas > 26) {
            JOptionPane.showMessageDialog(this, "La capacidad es demasiado grande para mostrar con letras A-Z.\nProba con mas asientos por fila.", "Cuadricula muy grande", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            butacasCacheGrilla = ApiClient.get("/api/salas/butacas", new TypeReference<List<Butaca>>() {});
        } catch (ApiClient.ApiException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al cargar butacas", JOptionPane.ERROR_MESSAGE);
            return;
        }

        panelGrilla.removeAll();
        panelGrilla.setLayout(new GridLayout(filas, asientosPorFila, 4, 4));

        int asientosRestantes = capacidad;
        for (int f = 0; f < filas; f++) {
            char letraFila = (char) ('A' + f);
            int asientosEnEstaFila = Math.min(asientosPorFila, asientosRestantes);
            for (int n = 1; n <= asientosPorFila; n++) {
                if (n > asientosEnEstaFila) {
                    panelGrilla.add(new JLabel(""));
                    continue;
                }
                char filaFinal = letraFila;
                int numeroFinal = n;
                JButton boton = new JButton(letraFila + "" + n);
                Butaca existente = buscarButaca(filaFinal, numeroFinal);
                if (existente == null) {
                    boton.setBackground(Color.LIGHT_GRAY);
                } else if (existente.isEstado()) {
                    boton.setBackground(new Color(220, 90, 90));
                } else {
                    boton.setBackground(new Color(120, 200, 120));
                }
                boton.setOpaque(true);
                boton.addActionListener(e -> onClickAsiento(filaFinal, numeroFinal));
                panelGrilla.add(boton);
            }
            asientosRestantes -= asientosEnEstaFila;
        }

        panelGrilla.revalidate();
        panelGrilla.repaint();
    }

    private Butaca buscarButaca(char fila, int numero) {
        for (Butaca b : butacasCacheGrilla) {
            if (b.getId().getFila() == fila && b.getId().getNumero() == numero) return b;
        }
        return null;
    }

    private void onClickAsiento(char fila, int numero) {
        Butaca existente = buscarButaca(fila, numero);
        if (existente == null) {
            try {
                ApiClient.post("/api/salas/butacas", new Butaca(fila, numero, false), Butaca.class);
            } catch (ApiClient.ApiException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo crear", JOptionPane.ERROR_MESSAGE);
            }
        } else if (!existente.isEstado()) {
            int confirmar = JOptionPane.showConfirmDialog(this, "La butaca " + fila + numero + " ya existe y esta libre.\n¿Eliminarla?", "Butaca existente", JOptionPane.YES_NO_OPTION);
            if (confirmar != JOptionPane.YES_OPTION) return;
            try {
                ApiClient.delete("/api/salas/butacas/" + fila + "/" + numero);
            } catch (ApiClient.ApiException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo eliminar", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "La butaca " + fila + numero + " esta ocupada (tiene una venta activa).", "Butaca ocupada", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        generarCuadricula();
    }
}
