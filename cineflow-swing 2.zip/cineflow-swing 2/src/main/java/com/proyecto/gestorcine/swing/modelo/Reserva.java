package com.proyecto.gestorcine.swing.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Reserva {
    private Integer codigoReserva;
    private ClienteRef cliente;
    private LocalDateTime fechaCompra;
    private List<Ticket> tickets = new ArrayList<>();
    private List<DetalleProducto> detallesProducto = new ArrayList<>();

    public Reserva() {}
    public Reserva(ClienteRef cliente, LocalDateTime fechaCompra) {
        this.cliente = cliente; this.fechaCompra = fechaCompra;
    }

    public Integer getCodigoReserva() { return codigoReserva; }
    public void setCodigoReserva(Integer codigoReserva) { this.codigoReserva = codigoReserva; }
    public ClienteRef getCliente() { return cliente; }
    public void setCliente(ClienteRef cliente) { this.cliente = cliente; }
    public LocalDateTime getFechaCompra() { return fechaCompra; }
    public void setFechaCompra(LocalDateTime fechaCompra) { this.fechaCompra = fechaCompra; }
    public List<Ticket> getTickets() { return tickets; }
    public void setTickets(List<Ticket> tickets) { this.tickets = tickets; }
    public List<DetalleProducto> getDetallesProducto() { return detallesProducto; }
    public void setDetallesProducto(List<DetalleProducto> detallesProducto) { this.detallesProducto = detallesProducto; }
}
