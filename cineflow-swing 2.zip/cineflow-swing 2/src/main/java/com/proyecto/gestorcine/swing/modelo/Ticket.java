package com.proyecto.gestorcine.swing.modelo;

public class Ticket {
    private Funcion funcion;
    private ButacaRef butaca;
    private int precio;

    public Ticket() {}
    public Ticket(Funcion funcion, ButacaRef butaca) {
        this.funcion = funcion; this.butaca = butaca; this.precio = 0;
    }

    public Funcion getFuncion() { return funcion; }
    public void setFuncion(Funcion funcion) { this.funcion = funcion; }
    public ButacaRef getButaca() { return butaca; }
    public void setButaca(ButacaRef butaca) { this.butaca = butaca; }
    public int getPrecio() { return precio; }
    public void setPrecio(int precio) { this.precio = precio; }

    public static class ButacaRef {
        private ButacaId id;
        public ButacaRef() {}
        public ButacaRef(char fila, int numero) { this.id = new ButacaId(fila, numero); }
        public ButacaId getId() { return id; }
        public void setId(ButacaId id) { this.id = id; }
    }
}
