package com.proyecto.gestorcine.swing.modelo;

public class ButacaId {
    private char fila;
    private int numero;

    public ButacaId() {}
    public ButacaId(char fila, int numero) { this.fila = fila; this.numero = numero; }

    public char getFila() { return fila; }
    public void setFila(char fila) { this.fila = fila; }
    public int getNumero() { return numero; }
    public void setNumero(int numero) { this.numero = numero; }
}
