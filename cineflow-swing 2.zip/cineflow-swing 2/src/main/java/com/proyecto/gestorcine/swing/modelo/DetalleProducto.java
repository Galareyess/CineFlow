package com.proyecto.gestorcine.swing.modelo;

import java.math.BigDecimal;

// Espejo de DetalleProducto.java del backend, para incluir compras de
// kiosco dentro de una Reserva.
public class DetalleProducto {
    private ProductoRef producto;
    private int cantidad;
    private BigDecimal precioUnitario; // el backend lo pisa con el precio actual del producto

    public DetalleProducto() {}
    public DetalleProducto(Integer codigoProducto, int cantidad) {
        this.producto = new ProductoRef(codigoProducto);
        this.cantidad = cantidad;
        this.precioUnitario = BigDecimal.ZERO;
    }

    public ProductoRef getProducto() { return producto; }
    public void setProducto(ProductoRef producto) { this.producto = producto; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }

    public static class ProductoRef {
        private Integer codigoProducto;
        public ProductoRef() {}
        public ProductoRef(Integer codigoProducto) { this.codigoProducto = codigoProducto; }
        public Integer getCodigoProducto() { return codigoProducto; }
        public void setCodigoProducto(Integer codigoProducto) { this.codigoProducto = codigoProducto; }
    }
}
