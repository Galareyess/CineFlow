package com.proyecto.gestorcine.swing.modelo;

import java.math.BigDecimal;

// Espejo de DetalleProducto.java del backend, para incluir compras de
// kiosco dentro de una Reserva.
public class DetalleProducto {
    private ProductoRef producto;
    private int cantidad;
    private BigDecimal precioUnitario; // el backend lo pisa con el precio actual del producto

    public DetalleProducto() {}
    public DetalleProducto(Integer codigoProducto, String nombre, BigDecimal precio, int stock, int cantidad) {
        this.producto = new ProductoRef(codigoProducto, nombre, precio, stock);
        this.cantidad = cantidad;
        this.precioUnitario = BigDecimal.ZERO;
    }

    public ProductoRef getProducto() { return producto; }
    public void setProducto(ProductoRef producto) { this.producto = producto; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(BigDecimal precioUnitario) { this.precioUnitario = precioUnitario; }

    public static class ProductoRef {
        private Integer codigoProducto;
        private String nombre;
        private BigDecimal precio;
        private int stock;

        public ProductoRef() {}

        public ProductoRef(Integer codigoProducto, String nombre, BigDecimal precio, int stock) {
            this.codigoProducto = codigoProducto;
            this.nombre = nombre;
            this.precio = precio;
            this.stock = stock;
        }

        public Integer getCodigoProducto() {
            return codigoProducto;
        }

        public void setCodigoProducto(Integer codigoProducto) {
            this.codigoProducto = codigoProducto;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        public BigDecimal getPrecio() {
            return precio;
        }

        public void setPrecio(BigDecimal precio) {
            this.precio = precio;
        }

        public int getStock() {
            return stock;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }
    }
}
