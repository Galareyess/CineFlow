package com.proyecto.gestorcine.swing.modelo;

public class Ticket {
    private Funcion funcion;
    private ButacaRef butaca;
    private int precio;

    public Ticket() {}
    public Ticket(Funcion funcion, ButacaRef butaca) {
        this.funcion = funcion; this.butaca = butaca; this.precio = 0;
    }

    public Funcion getFuncion() { return funcion; }
    public void setFuncion(Funcion funcion) { this.funcion = funcion; }
    public ButacaRef getButaca() { return butaca; }
    public void setButaca(ButacaRef butaca) { this.butaca = butaca; }
    public int getPrecio() { return precio; }
    public void setPrecio(int precio) { this.precio = precio; }

    public static class ButacaRef {
        private char fila;
        private int numero;
        private boolean estado;

        public ButacaRef() {}

        public ButacaRef(char fila, int numero) {
            this.fila = fila;
            this.numero = numero;
            this.estado = false;
        }
        public char getFila() {
            return fila;
        }

        public void setFila(char fila) {
            this.fila = fila;
        }

        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }

        public boolean isEstado() {
            return estado;
        }

        public void setEstado(boolean estado) {
            this.estado = estado;
        }
    }
}
